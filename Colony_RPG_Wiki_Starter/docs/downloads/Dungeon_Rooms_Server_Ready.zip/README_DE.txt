Dungeon Rooms – Server Ready
Minecraft 1.21.1 | Datapack-Format 48

INHALT
Dieses Datapack enthält 30 zusätzliche NBT-Strukturdateien für Dimensional
Dungeons. Die Dateien stellen verschiedene Raum- und Fallenstrukturen bereit,
die von der Dungeon-Mod verwendet werden können.

INSTALLATION
1. Sichere deine Welt bzw. teste das Datapack zuerst in einer Weltkopie.
2. Lege die ZIP unverändert in den datapacks-Ordner der gewünschten Welt.
3. Starte die Welt bzw. den Server neu oder führe /reload aus.
4. Prüfe mit /datapack list, ob das Datapack aktiviert ist.

HINWEISE
- Das Paket enthält Strukturdateien im Namespace dimdungeons.
- Es verwendet Datapack-Format 48 für Minecraft 1.21.1.
- In der bereitgestellten ZIP ist keine Versionsnummer angegeben.
- Die ZIP enthält Strukturdateien, aber keine eigene JSON-Konfiguration
  oder Versionshistorie.
