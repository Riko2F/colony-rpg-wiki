Bountiful RPG Quest Add-on 1.5 – Colony RPG
Minecraft 1.21.1 | Bountiful 8.0.0-beta.2

INHALT
- Ein zusätzliches Dekret: Colony RPG
- 23 Quest-Vorlagen: 5 Kolonie/Abenteuer-Lieferungen, 3 normale Monsterjagden, 2 Epic-Gegner und 13 Bossvarianten.
- Cataclysm-Bosse: Ender Guardian, Netherite Monstrosity, Ignis, Harbinger, Leviathan, Ancient Remnant, Maledictus, Aptrgangr und Wadjet. Scylla ist nicht enthalten.
- Kolonie-/Abenteuer-Lieferaufträge sind maximal Rare.
- Monster-/Bossaufträge enthalten Common, Epic und Legendary gemäß Vorlage.

MÜNZREGELN
- Common: Kupfermünzen
- Uncommon/Rare: Eisenmünzen (zusätzlich zu passenden Sachbelohnungen)
- Epic: maximal 2 Messingmünzen
- Legendary: Goldmünzen (maximal 1 pro Reward-Eintrag)
- Keine Zink- oder Netherite-Münzen als Questbelohnung.

INSTALLATION
1. Welt sichern.
2. Frühere Versionen dieses Add-ons aus dem Weltordner datapacks entfernen.
3. Diese ZIP unverändert in <Weltordner>/datapacks legen.
4. Welt starten und /reload ausführen.
5. Dekret erzeugen: /bo gen decree type colony_rpg

WICHTIG
Die JSON-Syntax und ZIP-Struktur wurden lokal geprüft. Ein vollständiger Ingame-Test wurde nicht durchgeführt. Bitte zuerst in einer Weltkopie testen. Bountiful kann die endgültige Auswahl und Zusammenstellung von Aufträgen/Belohnungen anhand seiner eigenen Wert- und Seltenheitslogik beeinflussen.
