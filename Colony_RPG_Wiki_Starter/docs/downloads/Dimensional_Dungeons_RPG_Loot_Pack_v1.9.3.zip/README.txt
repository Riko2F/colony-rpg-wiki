Dimensional Dungeons – Colony RPG Loot Pack v1.9.3
Minecraft 1.21.1 | NeoForge | Datapack-Format 48

INHALT
Dieses Datapack erweitert die Beute in Dimensional Dungeons und ausgewählten
Mob- und Struktur-Loot-Tabellen. Die Version 1.9.3 ergänzt die
Rüstungspfade von Berserker und Barde sowie die dazugehörigen
Armory-Upgrade-Kristalle.

BERSERKER-RÜSTUNGEN
- Tier 1: Wildling
- Tier 2: Northling
- Tier 3: Netherite Northling und Norse Warlord

BARDEN-RÜSTUNGEN
- Tier 1: Entertainer
- Tier 2: Troubadour
- Tier 3: Netherite Troubadour und The Storyteller

UPGRADE-KRISTALLE
- Ravager-Upgrade-Kristall
- Virtuoso-Upgrade-Kristall
Die beiden Kristalle wurden den regulären Armory-Upgrade-Kristall-Pools
in Dimensional-Dungeons-Truhen der Stufen 1 bis 3 hinzugefügt.

MÜNZ- UND MOB-BEUTE
Die Version enthält außerdem die in den vorherigen Versionen eingeführten
Münz-Loot-Anpassungen:
- MineColonies Common: 35 % Gesamtchance (Kupfer 25 %, Eisen 10 %).
- MineColonies Elite: 40 % Gesamtchance (Zink 20 %, Messing 16 %, Gold 4 %).
- MineColonies Boss: 50 % Gesamtchance (Messing 15 %, Gold 25 %, Netherite 10 %).
- Cataclysm-Bosse verwenden eine eigene Tabelle mit derselben Verteilung
  und 50 % Gesamtchance.
Andere Mob-Kategorien und die ursprünglichen Struktur-Beuteeinträge
bleiben gegenüber Version 1.8 unverändert.

INSTALLATION
1. Sichere deine Welt bzw. teste das Datapack zuerst in einer Weltkopie.
2. Entferne ältere Versionen dieses Loot-Packs aus dem datapacks-Ordner.
3. Lege diese ZIP unverändert in den datapacks-Ordner deiner Welt.
4. Starte die Welt bzw. den Server neu oder führe /reload aus.
5. Prüfe mit /datapack list, ob das Datapack aktiviert ist.

HINWEISE
- Das Datapack ist für Minecraft 1.21.1 ausgelegt (Datapack-Format 48).
- Die Rüstungs- und Kristalleinträge sind optional eingebunden.
- Die Loot-Verteilung kann je nach Dungeon, Gegner und Loot-Konfiguration
  unterschiedlich ausfallen.
