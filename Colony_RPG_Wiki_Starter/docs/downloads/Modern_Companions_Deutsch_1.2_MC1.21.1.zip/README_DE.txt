Modern Companions – Deutsche Übersetzung 1.2
Minecraft 1.21.1 | Resource-Pack-Format 34

INHALT
Dieses Resource Pack ergänzt die deutsche Übersetzung für Modern Companions.
Die vorhandene Sprachdatei wurde überarbeitet und die zuvor englischen bzw.
gemischtsprachigen Texte ins Deutsche übertragen.

ÜBERSETZTE BEREICHE
- Begleiter, Klassen und Beschwörungsgegenstände
- Gegenstände, Waffen, Rüstungen und Tränke
- Menüs, Inventare, Journal und Statusanzeigen
- Berufe, Arbeitsmeldungen und Begleiter-Verhalten
- Eigenschaften und Hintergrundgeschichten
- Nachrichten, Werkzeugbeschreibungen und Konfigurationstexte

INSTALLATION IM EINZELSPIELER
1. Entpacke die ZIP-Datei nicht.
2. Öffne den Minecraft-Ordner und dort den Ordner resourcepacks.
3. Lege die ZIP-Datei in diesen Ordner.
4. Starte Minecraft oder öffne die Resource-Pack-Auswahl erneut.
5. Aktiviere „Modern Companions – Deutsche Übersetzung 1.2“.
6. Stelle die Spielsprache unter Optionen → Sprache auf Deutsch (Deutschland).

WICHTIG
- Dieses Paket ist ein clientseitiges Resource Pack. Es gehört in den
  resourcepacks-Ordner des Minecraft-Clients, nicht in den datapacks-Ordner
  einer Welt und nicht in den mods-Ordner.
- Jeder Spieler muss das Resource Pack auf seinem eigenen Client aktivieren.
- Der Server benötigt dieses Resource Pack nicht, damit die Übersetzungen
  beim Spieler angezeigt werden.
- Der Modname „Modern Companions“, technische Kennungen und einige
  etablierte Fachbegriffe bleiben als Eigen- bzw. technische Namen erhalten.
