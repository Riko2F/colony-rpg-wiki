Modern Companions 4.60 – Worldgen-Whitelist 1.1
Minecraft 1.21.1 | Datapack-Format 48

ZIEL
Es sollen nur Strukturen generieren, die Begleiter beherbergen bzw. einen
Begleiter-Spawnplatz enthalten. Reine Funktions-/Dekorationsgebäude werden aus
den beiden Modern-Companions-Struktur-Sets entfernt.

BEHALTENE STRUKTUREN
- Allgemeine Begleiterhäuser (Oak/Birch/Sandstone/Acacia/Spruce/Dark Oak/
  Terracotta sowie House und Largehouse-Varianten). Diese verwenden den
  gemeinsamen Begleiter-Pool.
- Berserker-Haus
- Alchemist-Haus
- Vanguard-Haus
- Scout-Haus
- Cleric-Haus

BEGLEITER-WHITELIST
- Archer
- Axeguard
- Berserker
- Vanguard
- Cleric
- Scout
- Alchemist

AUSGESCHLOSSEN
- Knight und Arbalist aus dem gemeinsamen Pool
- Beastmaster und Stormcaller (dedizierte Pools geleert und Häuser nicht mehr
  in den Struktur-Sets enthalten)
- Nicht-Begleiter-Gebäude wie Lumber, Smith, Watermill, Windmill, Church und
  Tower1/Tower2 sind nicht mehr Teil der Struktur-Sets.

WICHTIGE EINSCHRAENKUNG
In den Worldgen-Dateien von Modern Companions 4.60 gibt es keine eigene
Necromancer-Struktur und keinen raw_necromancer-Pool. Necromancer kann mit
DIESEM Datapack daher nicht als Weltgenerierungs-Begleiter hinzugefügt werden.
Wizard-/Necromancer-Zuordnung wird nicht erfunden.

INSTALLATION
1. ZIP unverändert in den datapacks-Ordner deiner Welt legen.
2. Die alte Version 1.0 aus dem datapacks-Ordner entfernen, damit keine
   doppelten/konkurrierenden Overrides aktiv sind.
3. Welt laden und /reload ausführen.
4. Mit /datapack list prüfen, ob dieses Datapack aktiviert ist.

HINWEISE
- Änderungen gelten für neu generierte Chunks. Bereits generierte Gebiete und
  dort vorhandene Gebäude werden nicht rückwirkend entfernt.
- Das Datapack löscht keine registrierten Entities, Beschwörungsitems oder
  Spawn-Eier und sperrt keine manuelle Beschwörung.
- Bestehende Spawn-/Strukturmechanik der Mod bleibt ansonsten unverändert.
